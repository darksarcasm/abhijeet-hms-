package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.ConnectionProvider;
import com.cg.hms.util.DbUtil;

public class HotelDAOImpl implements IHotelDAO {
	
	

	@Override
	public List<Hotel> listHotels() throws HMSException {
		List<Hotel> hotelList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn.prepareStatement(IQueryMapper.LIST_HOTELS);) {

			ResultSet rs = st.executeQuery();

			hotelList = new ArrayList<Hotel>();
	
			while (rs.next()) {
				
				Hotel hotel = new Hotel();
				hotel.setHotelId(rs.getInt(1));
				hotel.setHotelName(rs.getString("hotelname"));
				hotel.setCity(rs.getString("city"));
				
				
				hotelList.add(hotel);
			}

			if (hotelList.size() == 0)
				hotelList = null;
		} catch (SQLException e) {
			e.printStackTrace(); // remove this later
			throw new HMSException("Unable To Fetch Hotels");
		}
		return hotelList;
	}

	@Override
	public Hotel findHotel(String hcode) throws HMSException {
		
			Hotel hotel = null;
			try (Connection conn = DbUtil.getConnection();
					PreparedStatement st = conn.prepareStatement(IQueryMapper.FIND_HOTEL);)  {
				
				st.setString(1, hcode);
				
				ResultSet rs = st.executeQuery();
				System.out.println("Find Hotel");			
				if(rs.next()){
					hotel = new Hotel();
					hotel.setHotelId(rs.getInt(1));
					hotel.setHotelName(rs.getString(2));
//					hotel.setStatus(Status.valueOf(rs.getString("status")));	
				}
				
			} catch (SQLException e) {
//				log.error(e);
				throw new HMSException("Unable To Fetch hotel");
			}
			return hotel;
		
	}
	@Override
	public List<Room> findRoom(String hcode) throws HMSException {
		
			List<Room> roomList;
			try (Connection conn = DbUtil.getConnection();
					PreparedStatement st = conn.prepareStatement(IQueryMapper.FIND_ROOMS);)  {
				
				st.setString(1, hcode);
				ResultSet rs = st.executeQuery();
				roomList = new ArrayList<Room>();
				System.out.println("Room Room Room");			
				while(rs.next()){
					Room room = new Room();
					room.setHotelId(rs.getInt(1));
					room.setRoomId(rs.getInt(2));
					room.setRoomType(rs.getString(4));
					room.setPerNightPrice(rs.getDouble(5));
					room.setAvailable(rs.getString(6));
//					hotel.setStatus(Status.valueOf(rs.getString("status")));	
					roomList.add(room);
				}
				
			} catch (SQLException e) {
//				log.error(e);
				throw new HMSException("Unable To Fetch roomdets");
			}
			return roomList;
		
	}
}
