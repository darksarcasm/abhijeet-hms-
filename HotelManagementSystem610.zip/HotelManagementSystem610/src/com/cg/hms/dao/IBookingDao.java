package com.cg.hms.dao;

import com.cg.hms.bean.Booking;
import com.cg.hms.exception.HMSException;

public interface IBookingDao {

	boolean saveBooking(Booking book) throws HMSException;
}
