package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Room;
import com.cg.hms.dao.HotelDAOImpl;
import com.cg.hms.dao.IHotelDAO;
import com.cg.hms.exception.HMSException;

public class RoomServiceImpl implements IRoomService {
	
private IHotelDAO hotelDao;
	
	public RoomServiceImpl() {
		hotelDao = new HotelDAOImpl();
	}

	@Override
	public List<Room> findRoom(String hcode) throws HMSException {
		// TODO Auto-generated method stub
		return hotelDao.findRoom(hcode);
	}

}
