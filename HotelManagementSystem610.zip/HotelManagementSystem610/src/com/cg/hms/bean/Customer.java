package com.cg.hms.bean;

public class Customer {
	
	String customerId;
	String customerName;
//	String customerName;

}
