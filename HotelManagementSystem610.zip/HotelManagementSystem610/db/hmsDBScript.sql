
//Create User Table
CREATE TABLE user (user_id varchar(4) PRIMARY KEY, 
password varchar(7),
role varchar(10), 
user_name varchar(20) UNIQUE,
mobile_no varchar(10),
phone varchar(10),
address varchar(25), 
email varchar(15));

//Create Hotel Table
CREATE TABLE hotel (hotelId number(4),
city varchar(10),
hotelName varchar (20),
address varchar(25),
description varchar(50),
avgRatePerNight number(10,2),
phoneNo1 varchar(10),
phoneNo2 varchar(10),
rating varchar(6),
email varchar(15),
fax varchar(15));

//Create RoomDetails Table
CREATE TABLE roomdetails (hotelId number(4), 
roomId number(4) unique, 
roomNo number(3),
roomType varchar2(20),
perNightRate number(10,2),
availability varchar2(3));

//Create BookingDetails Table
CREATE TABLE bookingdetails (bookingId number(4),
roomId number(4),
userId number(4),
bookedFrom date,
bookedTo date,
noofadults number(3),
noofchildren number(3),
amount number(10,2));

//Insert into Hotel Table
INSERT INTO Hotel (hotelId, hotelName, city) values ('1001','Marriot','Bangalore');
INSERT INTO Hotel (hotelId, hotelName, city) values ('1002','TAJ','Mumbai');
INSERT INTO Hotel (hotelId, hotelName, city) values ('1003','Trident','Mumbai');

//Insert into RoomDetails
insert into roomdetails values(1001,201,301,'AC',6000,'Yes');
insert into roomdetails values(1001,202,302,'AC',6000,'Yes');
insert into roomdetails values(1001,203,401,'Non-AC',4000,'Yes');
insert into roomdetails values(1001,204,402,'Delux AC',8000,'Yes');
